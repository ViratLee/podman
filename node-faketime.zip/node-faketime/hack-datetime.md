

Good question. **No, you cannot skip installing `libfaketime`** — the library must exist inside the container for it to work. But if you **can't modify the Dockerfile**, here are alternatives:

---

### Option 1: Override in `compose.yml` (No Dockerfile change needed)

Use a **multi-stage build override** directly in compose — build from the original image and install `libfaketime` on top:

```yaml
services:
  node-app:
    build:
      context: .
      dockerfile_inline: |
        FROM node:20-slim
        RUN apt-get update && apt-get install -y --no-install-recommends libfaketime && rm -rf /var/lib/apt/lists/*
        WORKDIR /app
        COPY app.js .
        EXPOSE 3000
        CMD ["node", "app.js"]
    container_name: node-faketime
    ports:
      - "3000:3000"
    environment:
      - FAKETIME=2026-12-15 10:00:00
      - LD_PRELOAD=/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1
```

But this still rebuilds the image, so it's essentially the same as having a Dockerfile.

---

### Option 2: Use `podman run` with `--env TZ` (Limited — only changes timezone, not date)

This **only changes the timezone**, not the actual date. Not what you want.

---

### Option 3: Set the date on the Podman machine (WSL level)

Change the date on the entire Podman WSL VM — affects **all containers**:

```powershell
podman machine ssh
sudo date -s "2026-12-15 10:00:00"
or 
podman machine ssh
sudo date -s "2026-12-15 $(date -u +%H:%M:%S)"
exit
```

This requires no changes to the Dockerfile or image at all. The downside is it affects **every container** running on that machine.

---

### Option 4: Mount `libfaketime` from outside (Advanced)

Build `libfaketime.so.1` separately and mount it into any container via compose:

```yaml
services:
  node-app:
    image: node:20-slim
    container_name: node-faketime
    ports:
      - "3000:3000"
    volumes:
      - ./app.js:/app/app.js
      - ./libfaketime.so.1:/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1:ro
    working_dir: /app
    command: node app.js
    environment:
      - FAKETIME=2026-12-15 10:00:00
      - LD_PRELOAD=/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1
```

You'd need to extract `libfaketime.so.1` once from a Debian container and save it locally. Then **no Dockerfile modification is needed** for any project.

---

### Recommendation

| Approach | Modify Dockerfile? | Affects all containers? | Complexity |
|----------|-------------------|------------------------|------------|
| **Option 3: `podman machine ssh` + `date -s`** | No | Yes | Easiest |
| **Option 4: Mount libfaketime** | No | No | Medium |
| **Option 1: `dockerfile_inline`** | No (but rebuilds) | No | Easy |

**For a tester**: **Option 3** is the simplest — just SSH into the Podman machine and change the system date. No code changes needed at all.


#### Resetting the Podman Machine Date

```powershell
podman machine ssh
sudo hwclock --hctosys
exit
```

This syncs the system clock from the hardware clock back to real time.

**Alternative (if `hwclock` doesn't work in WSL):**

```powershell
podman machine ssh
sudo date -s "2026-03-15 $(date -u +%H:%M:%S)"
exit
```

Or restart the machine entirely — it resets to real time on boot:

```powershell
podman machine stop
podman machine start
```