# Node Faketime Demo

> A simple Node.js container with a **fake system date** using `libfaketime`.

---

## Project Files

| File           | Purpose                                              |
| -------------- | ---------------------------------------------------- |
| `Dockerfile`   | Node 20 image with `libfaketime` installed           |
| `compose.yml`  | Compose file — sets fake date to **2026-12-15**      |
| `app.js`       | HTTP server that returns the container's current date |

---

## How It Works

The [`libfaketime`](https://github.com/wolfcw/libfaketime) library intercepts system time calls inside the container.

Two environment variables in `compose.yml` control it:

| Variable      | Description                                  |
| ------------- | -------------------------------------------- |
| `FAKETIME`    | The fake date/time (e.g. `2026-12-15 10:00:00`) |
| `LD_PRELOAD`  | Loads the faketime library into every process |

To change the date, edit the `FAKETIME` value in `compose.yml` and restart.

---

## Prerequisites

Install a compose provider (if not already installed):

```powershell
pip install podman-compose
```

---

## Run

### Option 1: Using Compose

```powershell
cd d:\projects\vscode-dev-container\demo\node-faketime
podman compose up -d --build
```

### Option 2: Without Compose

```powershell
cd d:\projects\vscode-dev-container\demo\node-faketime
podman build -t node-faketime .
podman run -d --name node-faketime -p 3000:3000 \
  -e "FAKETIME=2026-12-15 10:00:00" \
  -e "LD_PRELOAD=/usr/lib/x86_64-linux-gnu/faketime/libfaketime.so.1" \
  node-faketime
```

---

## Test

```powershell
curl http://localhost:3000
```

Expected response:

```json
{
  "message": "Hello from Node.js!",
  "containerDate": "2026-12-15T10:00:00.000Z",
  "formatted": "12/15/2026, 10:00:00 AM"
}
```

---

## Cleanup

```powershell
# Stop and remove (compose)
podman compose down

# Or stop and remove (manual)
podman stop node-faketime
podman rm node-faketime
```

---

## Troubleshooting

| Error | Solution |
| ----- | -------- |
| `exec: "podman-compose": not found in %PATH%` | Run `pip install podman-compose` |
| `exec: "docker-compose": not found in %PATH%` | Run `pip install podman-compose` (or `winget install Docker.DockerCompose`) |
| Container date not changing | Make sure `LD_PRELOAD` path is correct for your image architecture |
