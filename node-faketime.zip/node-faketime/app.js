const http = require("http");

const server = http.createServer((req, res) => {
  const now = new Date();
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(
    JSON.stringify({
      message: "Hello from Node.js!",
      containerDate: now.toISOString(),
      formatted: now.toLocaleString(),
    })
  );
});

server.listen(3000, () => {
  console.log(`Server running on port 3000`);
  console.log(`Container date: ${new Date().toISOString()}`);
});
